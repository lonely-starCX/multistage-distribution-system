package cn.lonelystar.mapper;

import cn.lonelystar.pojo.Storages;
import tk.mybatis.mapper.common.Mapper;

public interface StoragesMapper extends Mapper<Storages> {
}