package cn.lonelystar.mapper;

import cn.lonelystar.pojo.Orders;
import tk.mybatis.mapper.common.Mapper;

public interface OrdersMapper extends Mapper<Orders> {
}