package cn.lonelystar.mapper;

import cn.lonelystar.pojo.Agents;
import tk.mybatis.mapper.common.Mapper;

public interface AgentsMapper extends Mapper<Agents> {
}