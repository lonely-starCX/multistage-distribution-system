package cn.lonelystar.mapper;

import cn.lonelystar.pojo.ProductsOrders;
import tk.mybatis.mapper.common.Mapper;

public interface ProductsOrdersMapper extends Mapper<ProductsOrders> {
}