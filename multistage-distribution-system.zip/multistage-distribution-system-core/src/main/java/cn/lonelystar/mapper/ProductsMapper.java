package cn.lonelystar.mapper;

import cn.lonelystar.pojo.Products;
import tk.mybatis.mapper.common.Mapper;

public interface ProductsMapper extends Mapper<Products> {
}