package cn.lonelystar.mapper;

import cn.lonelystar.pojo.Admins;
import tk.mybatis.mapper.common.Mapper;

public interface AdminsMapper extends Mapper<Admins> {
}