package cn.lonelystar.mapper;

import cn.lonelystar.pojo.Customers;
import tk.mybatis.mapper.common.Mapper;

public interface CustomersMapper extends Mapper<Customers> {
}