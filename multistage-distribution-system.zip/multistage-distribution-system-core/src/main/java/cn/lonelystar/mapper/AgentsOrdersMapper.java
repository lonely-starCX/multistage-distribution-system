package cn.lonelystar.mapper;

import cn.lonelystar.pojo.AgentsOrders;
import tk.mybatis.mapper.common.Mapper;

public interface AgentsOrdersMapper extends Mapper<AgentsOrders> {
}