package cn.lonelystar.mapper;

import cn.lonelystar.pojo.FleeingOrders;
import tk.mybatis.mapper.common.Mapper;

public interface FleeingOrdersMapper extends Mapper<FleeingOrders> {
}