package cn.lonelystar.mapper;

import cn.lonelystar.pojo.Carts;
import tk.mybatis.mapper.common.Mapper;

public interface CartsMapper extends Mapper<Carts> {
}