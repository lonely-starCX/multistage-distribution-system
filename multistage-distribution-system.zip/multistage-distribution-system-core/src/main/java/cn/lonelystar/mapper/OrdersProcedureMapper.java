package cn.lonelystar.mapper;

import cn.lonelystar.pojo.OrdersProcedure;
import tk.mybatis.mapper.common.Mapper;

public interface OrdersProcedureMapper extends Mapper<OrdersProcedure> {
}